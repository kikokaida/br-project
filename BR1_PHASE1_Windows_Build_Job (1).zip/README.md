# Automated Windows compilation for BR1 Phase 1

**Prepared build job. No Windows executable has been produced or tested yet.**

This small repository package is ready for a Windows GitHub Actions build. It
contains the exact previously delivered diagnostic patch and build orchestration.
The original engine and game project are not needed by the cloud build.

The current chat machine runs Linux and has no Windows compiler. The GitHub
connection is now confirmed, but repository and Actions tools have not been
exposed to this running session. No job has been submitted. Once those tools are
available, repository write access, permission to run Actions, and runner
resources must be checked before submission.

## What the job does

1. Uses a fresh `windows-2022` runner and Visual Studio 2022 x64 tools.
2. Fetches UPBGE commit `b1b35c48872b32c8bd4134f0cba759224b40f8df`.
3. Checks the delivered patch's SHA256, applies it, and verifies every entry in
   its source manifest. The patch is unchanged.
4. Runs the delivered `Build-Windows.ps1` with two compilation jobs. That script
   resolves the exact Windows dependency revision, downloads its LFS libraries,
   builds and installs a separate engine, and runs the recorder and available
   upstream tests.
5. Starts the installed `blender.exe --version` if the build script succeeds.
6. Saves machine details, build status, executable hashes, and logs. When both
   installed executables exist, it also saves the installed engine and benchmark
   tools, even if a later test failed. Read `logs/BUILD_STATUS.json` before using
   that artifact.

Only a manual Actions dispatch starts a build. The job token has read-only
repository access; no public release or deployment is created. Artifacts expire
after seven days. The repository's visibility and billing must be reviewed
before dispatch; this package does not enable paid runners or change budgets.

GitHub documents Windows runners for private repositories with 2 CPUs, 8 GB RAM,
and 14 GB SSD storage. A complete Blender/UPBGE build with dependencies can exceed
the resources available on a standard runner. This job records actual machine
resources and failures; it does not disable engine features to force the build
to fit. A resource failure would require a suitable Windows machine or runner.
[GitHub runner specifications](https://docs.github.com/en/actions/reference/runners/github-hosted-runners)

## Submission once access is available

Put this package's contents at the root of a separate build repository, including
the workflow directory. Open Actions, select **BR1 Phase 1 diagnostic Windows
engine**, and dispatch it. This has not been uploaded or dispatched from the
current session. The assistant can manage submission and diagnose build errors
when repository and Actions access are available.

After a successful build, download the engine artifact and extract it into a
separate directory. It contains the layout expected by the existing benchmark
launcher:

- `BR1_PHASE1_engine` contains the diagnostic executables and runtime.
- `upbge/diagnostics/br1_phase1/Run-Benchmark.ps1` launches the existing game.
- `logs/BUILD_STATUS.json` reports build and test status.

The existing `PLAY.bat` continues to use the original engine. Windows gameplay
and performance measurements remain local verification steps. Building an
executable is not evidence of higher FPS or gameplay parity.

## Validation in this session

The patch SHA256 and source-manifest hashes were checked against the delivered
source. The workflow was parsed as YAML and its local script path was checked.
The wrapper and workflow have not executed on Windows. Native engine compilation,
Windows tests, and gameplay remain **NOT RUN**.
